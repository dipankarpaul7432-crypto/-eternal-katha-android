ETERNAL KATHA AI STUDIO - Native Android Project

1. Open this unzipped folder in Android Studio (Ladybug / Hedgehog or newer).
2. Let Gradle sync dependencies.
3. Connect your Android phone with USB Debugging enabled.
4. Click Run (Shift + F10) or build APK via: ./gradlew assembleDebug
5. Install on phone using: adb install -r app/build/outputs/apk/debug/app-debug.apk
