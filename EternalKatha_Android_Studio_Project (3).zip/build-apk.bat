@echo off
echo ========================================================
echo  ETERNAL KATHA AI STUDIO - Android APK Build & USB Install
echo ========================================================
echo Step 1: Building Android APK with Gradle...
call gradlew.bat assembleDebug
if %ERRORLEVEL% NEQ 0 (
    echo Error: Gradle build failed. Ensure JDK 17+ and Android SDK are installed.
    pause
    exit /b %ERRORLEVEL%
)
echo.
echo Step 2: APK successfully generated at: app\build\outputs\apk\debug\app-debug.apk
echo.
echo Step 3: Checking for connected USB Android device...
adb devices
echo.
echo Step 4: Installing to phone via USB...
adb install -r app\build\outputs\apk\debug\app-debug.apk
echo.
echo ========================================================
echo  Success! Eternal Katha AI Studio installed on phone.
echo ========================================================
pause
