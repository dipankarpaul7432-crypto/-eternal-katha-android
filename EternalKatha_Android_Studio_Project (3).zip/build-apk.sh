#!/usr/bin/env bash
set -e
echo "========================================================"
echo " ETERNAL KATHA AI STUDIO - Android APK Build & USB Install"
echo "========================================================"
echo "Step 1: Building Android APK with Gradle..."
chmod +x ./gradlew
./gradlew assembleDebug

echo ""
echo "Step 2: APK successfully generated at:"
echo "app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "Step 3: Checking USB Android device connection via ADB..."
adb devices
echo ""
echo "Step 4: Installing to phone via USB..."
adb install -r app/build/outputs/apk/debug/app-debug.apk
echo ""
echo "Success! Eternal Katha AI Studio installed on phone."
