# ETERNAL KATHA AI STUDIO — Android USB & OTG Installation Guide
# অ্যান্ড্রয়েড ফোনে ইউএসবি (USB) ও ওটিজি (OTG) দিয়ে অ্যাপ ইনস্টলেশন নির্দেশিকা

---

## পদ্ধতি ১: সাধারণ USB ফাইল ট্রান্সফার (MTP Mode - সবচেয়ে সহজ)

1. **APK তৈরি করা:**
   - Android Studio-তে প্রজেক্টটি খুলে `Build > Build Bundle(s) / APK(s) > Build APK(s)`-এ ক্লিক করুন অথবা কমান্ড চালান:
     ```bash
     ./gradlew assembleDebug
     ```
   - তৈরি হওয়া APK ফাইলের অবস্থান: `app/build/outputs/apk/debug/app-debug.apk`

2. **USB ক্যাবল দিয়ে ফোন সংযুক্ত করুন:**
   - আপনার Android ফোনটিকে USB ক্যাবল দিয়ে কম্পিউটারের সাথে যুক্ত করুন।
   - ফোনের স্ক্রিনের নোটিফিকেশন বার থেকে **"File Transfer" বা "MTP"** মোড নির্বাচন করুন।

3. **ফাইল কপি ও ফোনে পেস্ট:**
   - কম্পিউটার থেকে `app-debug.apk` ফাইলটি কপি করে ফোনের `Download` ফোল্ডারে পেস্ট করুন।

4. **ফোন থেকে ইনস্টল করুন:**
   - ফোনের **Files / File Manager** অ্যাপে গিয়ে `Download` ফোল্ডারের `app-debug.apk` ফাইলটিতে ট্যাপ করুন।
   - ফোনে "Install unknown apps" অনুমতি চাইলে সেটিংসে গিয়ে `Allow from this source` অন করে **Install** বাটনে চাপুন।

---

## পদ্ধতি ২: USB Flash Drive / OTG অ্যাডাপ্টার দিয়ে ইনস্টল (কম্পিউটার ছাড়াও)

1. কম্পিউটারে তৈরি হওয়া `app-debug.apk` ফাইলটি যেকোনো সাধারণ USB পেনড্রাইভে (Flash Drive) কপি করে নিন।
2. একটি **USB OTG অ্যাডাপ্টার** দিয়ে পেনড্রাইভটি আপনার Android ফোনের চার্জিং পোর্টে সংযুক্ত করুন।
3. ফোনের নোটিফিকেশন থেকে পেনড্রাইভ ওপেন করুন অথবা **Files / File Manager** অ্যাপে যান।
4. পেনড্রাইভে থাকা `app-debug.apk` ফাইলে ট্যাপ করে ইনস্টল করে নিন।

---

## পদ্ধতি ৩: ADB Command দিয়ে USB Debugging ইনস্টলেশন (ডেভেলপারদের জন্য ১-ক্লিকে)

1. **ফোনে Developer Options ও USB Debugging চালু করুন:**
   - ফোনের `Settings > About phone`-এ গিয়ে `Build number` অপশনে পরপর ৭ বার ট্যাপ করুন।
   - `Settings > System > Developer options`-এ গিয়ে **USB Debugging** চালু করুন।

2. **USB ক্যাবল দিয়ে ফোন কম্পিউটারে লাগান:**
   - ফোনের স্ক্রিনে "Allow USB debugging?" প্রম্পট আসলে "Always allow" দিয়ে **Allow** করুন।

3. **টার্মিনাল বা কমান্ড প্রম্পটে চালান:**
   ```bash
   # ডিভাইস কানেকশন চেক করুন
   adb devices

   # এক ক্লিকে ফোনে APK ইনস্টল করুন
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   - স্ক্রিনে **Success** বার্তা এলে অ্যাপটি আপনার ফোনের অ্যাপ ড্রয়ারে সফলভাবে ইনস্টল হয়ে যাবে!

---

## পদ্ধতি ৪: কোনো ক্যাবল ছাড়া সরাসরি ফোনে PWA / WebAPK ইনস্টল (Wireless)

কোনো ক্যাবল বা কম্পিউটার ছাড়াই মোবাইল ফোনের Google Chrome ব্রাউজারে অ্যাপটির লিংক খুলে ওপরের ডানদিকের থ্রি-ডট (⋮) মেনু থেকে **"Install app" বা "Add to Home screen"**-এ চাপ দিয়ে সরাসরি ফোনে নেটিভ অ্যাপের মতো ইনস্টল করে নিতে পারবেন।
