# Eternal Katha AI Studio ProGuard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}
-keep class androidx.media3.transformer.** { *; }
-keep class androidx.media3.effect.** { *; }
-keep class com.eternalkatha.aistudio.data.model.** { *; }
-dontwarn androidx.media3.**
