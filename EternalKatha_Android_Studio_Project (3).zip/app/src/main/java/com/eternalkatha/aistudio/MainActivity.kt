package com.eternalkatha.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.eternalkatha.aistudio.ui.screens.MainStudioScreen
import com.eternalkatha.aistudio.ui.theme.EternalKathaTheme
import com.eternalkatha.aistudio.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EternalKathaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF08080A)
                ) {
                    MainStudioScreen(viewModel = viewModel)
                }
            }
        }
    }
}
