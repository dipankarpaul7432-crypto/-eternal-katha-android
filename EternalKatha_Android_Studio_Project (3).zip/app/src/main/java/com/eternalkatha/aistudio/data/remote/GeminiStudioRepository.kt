package com.eternalkatha.aistudio.data.remote

import com.eternalkatha.aistudio.data.model.AspectRatio
import com.eternalkatha.aistudio.data.model.NarratorVoiceProfile
import com.eternalkatha.aistudio.data.model.Scene
import com.eternalkatha.aistudio.data.model.SubtitleSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class GeminiStudioRepository {

    val builtInVoiceProfiles = listOf(
        NarratorVoiceProfile(
            id = "bhagavata-purana",
            nameBengali = "ভাগবত পুরাণ মহাকাব্যিক কথক (ডিফল্ট)",
            nameEnglish = "Bhagavata Purana Epic Narrator",
            gender = "male",
            geminiVoice = "Fenrir",
            toneBengali = "গম্ভীর, রাশভারী ও আধ্যাত্মিক",
            resonanceBengali = "চেস্ট-রেজোন্যান্ট ব্যারিটোন (85-110Hz)",
            stylePrompt = "Deep, rich, warm, mature Indian Bengali male voice with a naturally resonant chest tone, smooth texture, clear Bengali pronunciation, and a captivating storytelling style.",
            descriptionBengali = "প্রাচীন ভারতীয় মহাকাব্য ও পুরাণ পাঠের অনুপ্রেরণায় তৈরি সুগভীর রাশভারী পুরুষ কণ্ঠ।"
        ),
        NarratorVoiceProfile(
            id = "mystic-thriller",
            nameBengali = "রহস্য ও পৌরাণিক রোমাঞ্চ কথক",
            nameEnglish = "Mystic Lore & Supernatural Thriller",
            gender = "male",
            geminiVoice = "Charon",
            toneBengali = "সুগভীর, গাঢ় রহস্যময় ও রোমাঞ্চকর",
            resonanceBengali = "লো-ফ্রিকোয়েন্সি ডার্ক ব্যারিটোন (75-100Hz)",
            stylePrompt = "Deep, atmospheric, whispery, mysterious Indian Bengali male narrator with intense emotional suspense and ancient folk mythology pacing.",
            descriptionBengali = "আদিম বাংলার রূপকথা, নিঝুম অমাবস্যার রাত ও অলৌকিক ঘটনার বর্ণনায় উপযোগী কণ্ঠ।"
        ),
        NarratorVoiceProfile(
            id = "epic-chronicle",
            nameBengali = "মহাকাব্যিক বীরত্বগাথা কথক",
            nameEnglish = "Mahabharata & Heroic Chronicle Narrator",
            gender = "male",
            geminiVoice = "Puck",
            toneBengali = "তেজস্বী, বীরত্বপূর্ণ ও রণহুংকারসুলভ",
            resonanceBengali = "কমান্ডিং রেজোন্যান্ট টেনর/ব্যারিটোন",
            stylePrompt = "Majestic, heroic, powerful, commanding Indian Bengali male narrator with rhythmic cadence and dramatic emotional peaks.",
            descriptionBengali = "কুরুক্ষেত্র যুদ্ধের রণকাহিনি বা রাজকীয় ইতিহাসের মতো বীরত্বগাথা বর্ণনার জন্য আদর্শ কণ্ঠ।"
        ),
        NarratorVoiceProfile(
            id = "devotional-grace",
            nameBengali = "করুণা ও প্রেমগাথা কথিকা (নারী কণ্ঠ)",
            nameEnglish = "Devotional & Poetic Grace (Female)",
            gender = "female",
            geminiVoice = "Kore",
            toneBengali = "করুণ, মমতাময়ী ও ভক্তিপূর্ণ",
            resonanceBengali = "স্মুথ কন্ট্রাল্টো / ওয়ার্ম মেজো",
            stylePrompt = "Warm, clear, deeply compassionate, heartfelt Indian Bengali female storyteller with devotional reverence and gentle pacing.",
            descriptionBengali = "কৃষ্ণপ্রেম, বৈষ্ণব পদাবলী বা গভীর আবেগপূর্ণ রূপকথা বর্ণনার জন্য অত্যন্ত মধুর কণ্ঠ।"
        )
    )

    suspend fun breakdownBengaliScript(
        script: String,
        ratio: AspectRatio,
        activeProfile: NarratorVoiceProfile
    ): List<Scene> = withContext(Dispatchers.IO) {
        val sentences = script.split(Regex("[।?!\\n]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val scenes = mutableListOf<Scene>()
        val total = sentences.size.coerceIn(2, 6)
        val chunkSize = (sentences.size + total - 1) / total

        for (i in 0 until total) {
            val fromIndex = (i * chunkSize).coerceAtMost(sentences.size)
            val toIndex = ((i + 1) * chunkSize).coerceAtMost(sentences.size)
            if (fromIndex >= toIndex) break

            val narration = sentences.subList(fromIndex, toIndex).joinToString("। ") + "।"
            val dur = (narration.split(Regex("\\s+")).size * 0.45).toInt().coerceIn(4, 8)

            scenes.add(
                Scene(
                    id = "sc-${i + 1}-${UUID.randomUUID()}",
                    sceneNumber = i + 1,
                    bengaliTitle = "দৃশ্য ${i + 1}: ${narration.take(16)}...",
                    bengaliNarration = narration,
                    visualDescription = "সিনেমাটিক দৃশ্যপট ও বায়ুমণ্ডলীয় আলো",
                    visualPrompt = "A cinematic dramatic scene in ancient Bengal, volumetric atmospheric lighting, 8k render",
                    mood = "গম্ভীর ও সিনেমাটিক",
                    shotType = "ওয়াইড শট",
                    durationSeconds = dur,
                    selectedVoice = activeProfile.geminiVoice,
                    voiceProfileId = activeProfile.id,
                    customVoicePrompt = activeProfile.stylePrompt,
                    subtitles = listOf(
                        SubtitleSegment(
                            id = "sub-${i + 1}",
                            text = narration,
                            relativeStart = 0.05f,
                            relativeEnd = 0.95f,
                            startTimeSeconds = 0.3,
                            endTimeSeconds = dur - 0.2
                        )
                    )
                )
            )
        }
        scenes
    }
}
