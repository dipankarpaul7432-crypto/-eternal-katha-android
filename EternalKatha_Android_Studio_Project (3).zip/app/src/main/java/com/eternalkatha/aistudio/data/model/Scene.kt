package com.eternalkatha.aistudio.data.model

enum class AspectRatio(val titleBengali: String, val width: Int, val height: Int) {
    PORTRAIT_9_16("রিল / শর্টস (9:16)", 720, 1280),
    LANDSCAPE_16_9("সিনেমাটিক (16:9)", 1280, 720)
}

data class SubtitleSegment(
    val id: String,
    val text: String,
    val relativeStart: Float = 0.05f,
    val relativeEnd: Float = 0.95f,
    val startTimeSeconds: Double = 0.3,
    val endTimeSeconds: Double = 4.8
)

data class Scene(
    val id: String,
    val sceneNumber: Int,
    val bengaliTitle: String,
    val bengaliNarration: String,
    val visualDescription: String,
    val visualPrompt: String,
    val mood: String,
    val shotType: String,
    val durationSeconds: Int = 5,
    val imageUrl: String? = null,
    val audioUrl: String? = null,
    val audioDuration: Double? = null,
    val selectedVoice: String = "Fenrir",
    val voiceProfileId: String = "bhagavata-purana",
    val customVoicePrompt: String? = null,
    val subtitles: List<SubtitleSegment> = emptyList(),
    val isGeneratingImage: Boolean = false,
    val isGeneratingAudio: Boolean = false
)

data class NarratorVoiceProfile(
    val id: String,
    val nameBengali: String,
    val nameEnglish: String,
    val gender: String, // "male" or "female"
    val geminiVoice: String, // "Fenrir", "Charon", "Puck", "Kore", "Zephyr"
    val toneBengali: String,
    val resonanceBengali: String,
    val stylePrompt: String,
    val descriptionBengali: String,
    val sampleTextBengali: String,
    val isBuiltIn: Boolean = true
)
