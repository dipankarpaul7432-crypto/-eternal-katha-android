package com.eternalkatha.aistudio.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFFFD700)
val GoldDark = Color(0xFFA67C1E)
val ObsidianBlack = Color(0xFF08080A)
val SurfaceDark = Color(0xFF141418)

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    secondary = GoldDark,
    background = ObsidianBlack,
    surface = SurfaceDark,
    onPrimary = Color.Black,
    onBackground = Color(0xFFF4ECD8),
    onSurface = Color(0xFFF4ECD8)
)

@Composable
fun EternalKathaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
