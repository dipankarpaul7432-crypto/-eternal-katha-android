package com.eternalkatha.aistudio.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eternalkatha.aistudio.data.model.AspectRatio
import com.eternalkatha.aistudio.data.model.NarratorVoiceProfile
import com.eternalkatha.aistudio.data.model.Scene
import com.eternalkatha.aistudio.data.remote.GeminiStudioRepository
import com.eternalkatha.aistudio.video.AndroidMedia3VideoExporter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class StudioUiState(
    val scriptText: String = "গভীর সুন্দরবনের বুক চিরে বয়ে চলেছে এক কুয়াশাচ্ছন্ন নদী। জোয়ারের জলে ভেসে ওঠে শত শত বছর পুরনো শিব মন্দিরের চূড়া।",
    val aspectRatio: AspectRatio = AspectRatio.PORTRAIT_9_16,
    val activeVoiceProfile: NarratorVoiceProfile,
    val scenes: List<Scene> = emptyList(),
    val isBreakingDown: Boolean = false,
    val isRenderingVideo: Boolean = false,
    val renderProgressPercent: Int = 0,
    val renderMessage: String = "",
    val renderedVideoFile: File? = null,
    val customAudioFileName: String? = null,
    val errorMessage: String? = null
)

class StudioViewModel(
    private val repository: GeminiStudioRepository = GeminiStudioRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        StudioUiState(activeVoiceProfile = repository.builtInVoiceProfiles[0])
    )
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    fun updateScript(text: String) {
        _uiState.value = _uiState.value.copy(scriptText = text)
    }

    fun setAspectRatio(ratio: AspectRatio) {
        _uiState.value = _uiState.value.copy(aspectRatio = ratio)
    }

    fun selectVoiceProfile(profile: NarratorVoiceProfile) {
        _uiState.value = _uiState.value.copy(
            activeVoiceProfile = profile,
            scenes = _uiState.value.scenes.map {
                it.copy(
                    selectedVoice = profile.geminiVoice,
                    voiceProfileId = profile.id,
                    customVoicePrompt = profile.stylePrompt
                )
            }
        )
    }

    fun handleCustomAudioSelected(context: Context, uri: Uri) {
        val fileName = uri.lastPathSegment ?: "custom_voice.mp3"
        _uiState.value = _uiState.value.copy(customAudioFileName = fileName)
    }

    fun breakdownScript() {
        val currentScript = _uiState.value.scriptText
        if (currentScript.isBlank()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBreakingDown = true, errorMessage = null)
            try {
                val parsedScenes = repository.breakdownBengaliScript(
                    script = currentScript,
                    ratio = _uiState.value.aspectRatio,
                    activeProfile = _uiState.value.activeVoiceProfile
                )
                _uiState.value = _uiState.value.copy(
                    scenes = parsedScenes,
                    isBreakingDown = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isBreakingDown = false,
                    errorMessage = "স্ক্রিপ্ট প্রসেসিং ব্যর্থ হয়েছে: ${e.localizedMessage}"
                )
            }
        }
    }

    fun exportVideo(context: Context) {
        val scenes = _uiState.value.scenes
        if (scenes.isEmpty()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRenderingVideo = true, renderProgressPercent = 0)
            try {
                val exporter = AndroidMedia3VideoExporter(context)
                val outputFile = File(context.filesDir, "eternal_katha_${System.currentTimeMillis()}.mp4")
                val result = exporter.exportProjectToMp4(
                    scenes = scenes,
                    aspectRatio = _uiState.value.aspectRatio,
                    outputFile = outputFile
                ) { percent, msg ->
                    _uiState.value = _uiState.value.copy(
                        renderProgressPercent = percent,
                        renderMessage = msg
                    )
                }
                _uiState.value = _uiState.value.copy(
                    isRenderingVideo = false,
                    renderedVideoFile = result
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isRenderingVideo = false,
                    errorMessage = "ভিডিও রেন্ডারিং ত্রুটি: ${e.localizedMessage}"
                )
            }
        }
    }
}
