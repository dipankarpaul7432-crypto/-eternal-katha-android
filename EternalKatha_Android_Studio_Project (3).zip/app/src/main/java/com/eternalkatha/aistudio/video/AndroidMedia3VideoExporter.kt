package com.eternalkatha.aistudio.video

import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.*
import com.eternalkatha.aistudio.data.model.Scene
import com.eternalkatha.aistudio.data.model.AspectRatio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCancellableCoroutine

class AndroidMedia3VideoExporter(private val context: Context) {

    suspend fun exportProjectToMp4(
        scenes: List<Scene>,
        aspectRatio: AspectRatio,
        outputFile: File,
        onProgress: (Int, String) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val width = aspectRatio.width
        val height = aspectRatio.height

        onProgress(5, "ভিডিও অ্যাসেট ও সাবটাইটেল প্রস্তুত করা হচ্ছে...")

        val editedMediaItems = mutableListOf<EditedMediaItem>()

        // 1. Build timed scene items with image + narration
        for ((index, scene) in scenes.withIndex()) {
            val sceneDurationUs = ((scene.audioDuration ?: scene.durationSeconds.toDouble()) * 1_000_000).toLong()
            val imageUri = Uri.parse(scene.imageUrl ?: "android.resource://${context.packageName}/drawable/placeholder")

            val mediaItem = MediaItem.Builder()
                .setUri(imageUri)
                .setImageDurationMs(sceneDurationUs / 1000)
                .build()

            val subtitleOverlay = createBengaliSubtitleOverlay(scene, width, height)

            val editedItem = EditedMediaItem.Builder(mediaItem)
                .setDurationUs(sceneDurationUs)
                .setEffects(Effects(emptyList(), listOf(subtitleOverlay)))
                .build()

            editedMediaItems.add(editedItem)
            onProgress(10 + (index * 50 / scenes.size), "দৃশ্য ${index + 1} প্রসেস করা হচ্ছে...")
        }

        // 2. Add 4-second Branded Outro: "ETERNAL KATHA — Stories Beyond Time"
        val outroDurationUs = 4_000_000L
        val outroMediaItem = createBrandedOutroMediaItem(width, height, outroDurationUs)
        editedMediaItems.add(outroMediaItem)

        // 3. Assemble Composition
        val sequence = EditedMediaItemSequence(editedMediaItems)
        val composition = Composition.Builder(listOf(sequence))
            .setTransmuxAudio(false)
            .setTransmuxVideo(false)
            .build()

        onProgress(65, "ভিডিও এনকোডিং শুরু হচ্ছে (H.264 MP4)...")

        suspendCancellableCoroutine { continuation ->
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        onProgress(100, "ভিডিও সফলভাবে রেন্ডার হয়েছে!")
                        continuation.resume(outputFile)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exception: ExportException) {
                        continuation.resumeWithException(exception)
                    }
                })
                .build()

            transformer.start(composition, outputFile.absolutePath)

            continuation.invokeOnCancellation {
                transformer.cancel()
            }
        }
    }

    private fun createBengaliSubtitleOverlay(scene: Scene, width: Int, height: Int): OverlayEffect {
        return OverlayEffect(listOf(
            TextureOverlay { presentationTimeUs ->
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#FFFDF7")
                    textSize = (width * 0.042f)
                    textAlign = Paint.Align.CENTER
                }
                val sec = presentationTimeUs / 1_000_000.0
                val activeSub = scene.subtitles.find { s ->
                    sec >= s.startTimeSeconds && sec <= s.endTimeSeconds
                }
                activeSub?.let {
                    val bgPaint = Paint().apply { color = Color.argb(210, 10, 10, 14) }
                    canvas.drawRoundRect(40f, height - 170f, width - 40f, height - 70f, 20f, 20f, bgPaint)
                    canvas.drawText(it.text, width / 2f, height - 105f, paint)
                }
                bitmap
            }
        ))
    }

    private fun createBrandedOutroMediaItem(width: Int, height: Int, durationUs: Long): EditedMediaItem {
        val outroBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outroBitmap)
        canvas.drawColor(Color.parseColor("#08080A"))

        val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFD700")
            textSize = width * 0.065f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("ETERNAL KATHA", width / 2f, height * 0.46f, brandPaint)

        val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E6CF8B")
            textSize = width * 0.032f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("STORIES BEYOND TIME", width / 2f, height * 0.52f, tagPaint)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = width * 0.035f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("ভিডিওটি ভালো লাগলে লাইক, কমেন্ট ও শেয়ার করুন", width / 2f, height * 0.64f, subPaint)

        val tempFile = File(context.cacheDir, "outro_${System.currentTimeMillis()}.png")
        outroBitmap.compress(Bitmap.CompressFormat.PNG, 100, tempFile.outputStream())

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.fromFile(tempFile))
            .setImageDurationMs(durationUs / 1000)
            .build()

        return EditedMediaItem.Builder(mediaItem).setDurationUs(durationUs).build()
    }
}
